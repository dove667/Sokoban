package Sokoban.Controller;

import Sokoban.Model.Account;
import Sokoban.Model.GameSystem;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;


public class LevelSceneController {
    @FXML
    private Button Btn_Level1, Btn_Level2, Btn_Level3, Btn_Level4, Btn_Level5, Btn_Level6, Btn_TimeMode;

    @FXML
    private Label Label_Mode;

    @FXML
    private AnchorPane Pane, Bottom;

    @FXML
    private ImageView Img_SUST2;

    @FXML
    private Button Btn_Return;



    public void initialize() {
        Account account = Account.loadAccount();

        if (!account.verifyAdimin()) {
            if (!account.isL1win()) {
                Btn_Level2.setDisable(true);
                Btn_Level2.setVisible(false);
                Btn_Level3.setDisable(true);
                Btn_Level3.setVisible(false);
                Btn_Level4.setDisable(true);
                Btn_Level4.setVisible(false);
                Btn_Level5.setDisable(true);
                Btn_Level5.setVisible(false);
                Btn_Level6.setDisable(true);
                Btn_Level6.setVisible(false);
            } else if (!account.isL2win()) {
                Btn_Level3.setDisable(true);
                Btn_Level3.setVisible(false);
                Btn_Level4.setDisable(true);
                Btn_Level4.setVisible(false);
                Btn_Level5.setDisable(true);
                Btn_Level5.setVisible(false);
                Btn_Level6.setDisable(true);
                Btn_Level6.setVisible(false);
            } else if (!account.isL3win()) {
                Btn_Level4.setDisable(true);
                Btn_Level4.setVisible(false);
                Btn_Level5.setDisable(true);
                Btn_Level5.setVisible(false);
                Btn_Level6.setDisable(true);
                Btn_Level6.setVisible(false);
            } else if (!account.isL4win()) {
                Btn_Level5.setDisable(true);
                Btn_Level5.setVisible(false);
                Btn_Level6.setDisable(true);
                Btn_Level6.setVisible(false);
            } else if (!account.isL5win()) {
                Btn_Level6.setDisable(true);
                Btn_Level6.setVisible(false);
            }
        }

        Btn_TimeMode.setFont(Font.font("Century", 20));
        Btn_Return.setFont(Font.font("Century", 20));
        Label_Mode.setFont(Font.font("Century", FontWeight.BOLD, 20));
        Btn_TimeMode.setBackground(new Background(new BackgroundFill(Color.GREEN, cornerRadii, Insets.EMPTY)));
        Btn_TimeMode.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, cornerRadii, BorderWidths.DEFAULT)));

    }

    CornerRadii cornerRadii = new CornerRadii(50, 50, 50, 50, false); // false 表示不使用默认的圆角

    private static boolean L1isTimeMode ;
    private static boolean L2isTimeMode ;
    private static boolean L3isTimeMode ;
    private static boolean L4isTimeMode ;
    private static boolean L5isTimeMode ;
    private static boolean L6isTimeMode ;

    public static boolean isL1isTimeMode() {
        return L1isTimeMode;
    }

    public static boolean isL2isTimeMode() {
        return L2isTimeMode;
    }

    public static boolean isL3isTimeMode() {
        return L3isTimeMode;
    }

    public static boolean isL4isTimeMode() {
        return L4isTimeMode;
    }

    public static boolean isL5isTimeMode() {
        return L5isTimeMode;
    }

    public static boolean isL6isTimeMode() {
        return L6isTimeMode;
    }

    @FXML
    void Level1BtnReleased() throws IOException {
        Account account = Account.loadAccount();
        AudioManager.stop();
        Stage primaryStage = (Stage) Btn_Level1.getScene().getWindow();
        URL url = getClass().getResource("/Sokoban/Fxml/Level1.fxml");
        Parent root = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        account.setCurrentLevel(1);
        Account.saveAccount(account);
        L1isTimeMode = setMode();
    }


    @FXML
    void Level2BtnReleased() throws IOException {
        Account account = Account.loadAccount();
        AudioManager.stop();
        Stage primaryStage = (Stage) Btn_Level2.getScene().getWindow();
        URL url = getClass().getResource("/Sokoban/Fxml/Level2.fxml");
        Parent root = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        account.setCurrentLevel(2);
        Account.saveAccount(account);
        L2isTimeMode = setMode();
    }

    @FXML
    void Level3BtnReleased() throws IOException {
        Account account = Account.loadAccount();
        AudioManager.stop();
        Stage primaryStage = (Stage) Btn_Level3.getScene().getWindow();
        URL url = getClass().getResource("/Sokoban/Fxml/Level3.fxml");
        Parent root = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        account.setCurrentLevel(3);Account.saveAccount(account);
        L3isTimeMode = setMode();
    }

    @FXML
    void Level4BtnReleased() throws IOException {
        Account account = Account.loadAccount();
        AudioManager.stop();
        Stage primaryStage = (Stage) Btn_Level4.getScene().getWindow();
        URL url = getClass().getResource("/Sokoban/Fxml/Level4.fxml");
        Parent root = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        account.setCurrentLevel(4);Account.saveAccount(account);
        L4isTimeMode = setMode();
    }

    @FXML
    void Level5BtnReleased() throws IOException {
        Account account = Account.loadAccount();
        AudioManager.stop();
        Stage primaryStage = (Stage) Btn_Level5.getScene().getWindow();
        URL url = getClass().getResource("/Sokoban/Fxml/Level5.fxml");
        Parent root = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        account.setCurrentLevel(5);Account.saveAccount(account);
        L5isTimeMode = setMode();
    }

    @FXML
    void Level6BtnReleased() throws IOException {
        Account account = Account.loadAccount();
        AudioManager.stop();
        Stage primaryStage = (Stage) Btn_Level5.getScene().getWindow();
        URL url = getClass().getResource("/Sokoban/Fxml/Level6.fxml");
        Parent root = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        account.setCurrentLevel(5);Account.saveAccount(account);
        L6isTimeMode = setMode();
    }

    @FXML
    void TimeModeBtnReleased() {
        if (Label_Mode.getText().equals("closed")) {
            Label_Mode.setText("open");
            Btn_TimeMode.setBackground(new Background(new BackgroundFill(Color.RED, cornerRadii, Insets.EMPTY)));
        } else {
            Label_Mode.setText("closed");
            Btn_TimeMode.setBackground(new Background(new BackgroundFill(Color.GREEN, cornerRadii, Insets.EMPTY)));
        }
    }

    @FXML
    void ReturnBtnClicked() throws IOException {
        Stage primaryStage = (Stage) Btn_Return.getScene().getWindow();
        URL url = getClass().getResource("/Sokoban/Fxml/LoginScene.fxml");
        Parent root = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
    }

    public boolean setMode() {
        return Label_Mode.getText().equals("open");
    }
}
